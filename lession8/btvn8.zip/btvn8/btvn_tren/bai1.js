let a = prompt('Nhap a: ')
a = Number(a)

if(a >= 18){
    console.log('du 18 tuoi thi quay tiep')
}
else if (a >= 16 && a < 18){
    console.log('doi them it nam nua')
}
else{
    console.log('con qua tre')
}
