let s = prompt('Nhap chuoi s: ')

if(s.length >= 8){
    console.log('chuoi nay ok')
}
else{
    console.log('qua ngan, dai them ty nua')
}
