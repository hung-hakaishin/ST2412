let sum = 0;

for(let i = 1; i <= 50; i++){
    sum += i;
}
console.log(sum)