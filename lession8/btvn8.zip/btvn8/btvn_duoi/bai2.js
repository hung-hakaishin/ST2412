// Hãy in ra màn hình console các số chia hết cho 9 trong đoạn [-100; 100]
for(let i = -100; i <= 100; i++){
    if(i % 9 === 0){
        console.log(i)
    }
}