let i = 1;
while( i <= 300){
    console.log(i)
    i++
}