for(let i = 1; i <= 500; i++){
    console.log(i)
}