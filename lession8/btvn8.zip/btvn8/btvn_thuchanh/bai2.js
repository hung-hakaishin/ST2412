for(let i = 1; i <= 300; i++){
    if(i % 2 === 0 && i % 3 === 0){
        console.log(i)
    }
}