let sum = 0
for (number = -30; number <= 50; number ++){
    if(number % 2 === 0){
        console.log(sum);
        sum = sum + number;
    }
}