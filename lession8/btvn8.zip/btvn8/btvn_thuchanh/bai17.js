const a = Math.floor(Math.random() * 5) + 5;
let n;
do {
  n = Number(prompt("Nhập n"));
} while (n !== a);